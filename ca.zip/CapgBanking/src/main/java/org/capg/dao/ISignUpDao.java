package org.capg.dao;

import org.capg.model.SignUpBean;

public interface ISignUpDao {
	
	public void createUser(SignUpBean signUp);

}
