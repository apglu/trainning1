package org.capg.dao;

import org.capg.model.LoginBean;

public interface ILoginDao {
	public boolean isValidLogin(LoginBean loginBean);
}
