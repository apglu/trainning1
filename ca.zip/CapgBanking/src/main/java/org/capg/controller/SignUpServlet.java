package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.model.SignUpBean;
import org.capg.service.ISignUpService;
import org.capg.service.SignUpServiceImpl;


@WebServlet("/SignUpServlet")
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    
	//capture data from view
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String dateOfBirth=request.getParameter("dateOfbirth");
		String email=request.getParameter("email");
		String mobile=request.getParameter("mobile");
		String password=request.getParameter("custPwd");
		String confirmPassword=request.getParameter("confimrCustPwd");
		boolean flag=password.equals("confirmPassword");
		
		String[] dates=dateOfBirth.split("-");
		
		//convert input into model
		SignUpBean signUp=new SignUpBean();
		ISignUpService signUpService=new SignUpServiceImpl();
		signUp.setFirstName(firstName);
		signUp.setLastName(lastName);
		signUp.setEmailId(email);
		signUp.setMobile(mobile);
		signUp.setDateOfBirth(LocalDate.of(Integer.parseInt(dates[0]), Integer.parseInt(dates[1]), Integer.parseInt(dates[2])));
		if(flag)
			signUp.setPassword(password);
		signUpService.createUser(signUp);
		
		
		
		
	}

}
