package org.capg.service;

import org.capg.dao.ISignUpDao;
import org.capg.dao.SignUpDaoImpl;
import org.capg.model.SignUpBean;

public class SignUpServiceImpl implements  ISignUpService{

	@Override
	public void createUser(SignUpBean signUp) {
		
		ISignUpDao signUpDao=new SignUpDaoImpl();
		signUpDao.createUser(signUp);
		
	}

}
