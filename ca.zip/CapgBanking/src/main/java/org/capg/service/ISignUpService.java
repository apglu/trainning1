package org.capg.service;

import org.capg.model.SignUpBean;

public interface ISignUpService {
	
	public void createUser(SignUpBean signup);

}
